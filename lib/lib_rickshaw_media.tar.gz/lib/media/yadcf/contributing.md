Use github issues only for bug reports or new features request

In case of bug always post a code sample that resembles your issue or event better provide a link to your page