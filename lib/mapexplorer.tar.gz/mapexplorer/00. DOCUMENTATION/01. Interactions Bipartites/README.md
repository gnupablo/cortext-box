Exemple réseau socio-semantique:

	États possibles:
	- - - - - - - - - 
	• SOC: Projection social, niveau global                 (voir  00_Bipartite-Components.png ,  [fig. b] )
	• SEM: Projection semantique, niveau global             (voir  00_Bipartite-Components.png ,  [fig. c] )
	• soc: Projection social, niveau local.
	• sem: Projection semantique, niveau local.
	• socsem: Projection socio-semantique, niveau local.    (voir  00_Bipartite-Components.png ,  [fig. a] )
		L'asterisk dans un état représente une selection des nœuds active.


	Actions possibles:
	- - - - - - - - - 
	• Sel: L'utilisateur sélectionne 1..* nœuds
	• ctype: L'utilisateur clique sur le boutton "Change Type".
	• clevel: L'utilisateur clique sur le boutton "Change Level".

