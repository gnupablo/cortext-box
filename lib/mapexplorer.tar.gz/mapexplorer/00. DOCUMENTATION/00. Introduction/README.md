TinawebJS


- "JS Mode": TinawebJS est utilisé juste a niveau Javascript (HTML+CSS+JS), sans aide des modules php/python. C'est la version standalone, ça veut dire "lecture d'un fichier GEXF ou JSON".
	- Graph uni-partite.  http://localhost/TinawebJS_2015/explorerjs.html?file=data/0-terms-terms-MainNodes.gexf

	- Graph bi-partite.   http://localhost/TinawebJS_2015/explorerjs.html?file=data/cnrsfolder/2015-11-06T15:15:02.121958_graph.json



- "JS+PHP Mode": Quand il y a des GEXF|JSON et en plus une BD en sqlite en format CorText (manager.cortext.net). En ce mode on dois declarer une db.json avec l'info necessaire.
	- Graph bi-partite.   http://localhost/TinawebJS_2015/explorerjs.html
