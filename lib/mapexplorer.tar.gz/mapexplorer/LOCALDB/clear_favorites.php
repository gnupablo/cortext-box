<?php

echo 'toto';
?>